document.getElementById("placeOrderBtn").addEventListener("click", function() {
    document.getElementById("popup").classList.remove("hidden");
  });
  
  document.getElementById("closePopupBtn").addEventListener("click", function() {
    document.getElementById("popup").classList.add("hidden");
  });
  