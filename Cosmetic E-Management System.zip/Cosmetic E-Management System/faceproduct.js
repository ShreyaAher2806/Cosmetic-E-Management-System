// Initial product price per item
const pricePerItem = 474;

// DOM elements
const itemQtyElement = document.getElementById("item-qty");
const totalItemsElement = document.getElementById("total-items");
const totalProductPriceElement = document.getElementById("total-product-price");
const totalDiscountElement = document.getElementById("total-discount");
const orderTotalElement = document.getElementById("order-total");
const discountNoticeElement = document.getElementById("discount-notice");

// Initial values
let itemQuantity = 1;
let totalDiscount = 13;

// Update price details dynamically
function updatePriceDetails() {
    const totalProductPrice = pricePerItem * itemQuantity;
    const orderTotal = totalProductPrice - totalDiscount;

    // Update DOM elements
    totalProductPriceElement.textContent = totalProductPrice.toFixed(2);
    totalDiscountElement.textContent = totalDiscount.toFixed(2);
    orderTotalElement.textContent = orderTotal.toFixed(2);
    discountNoticeElement.textContent = totalDiscount.toFixed(2);
    totalItemsElement.textContent = itemQuantity;
}

// Increase quantity
function increaseQuantity() {
    itemQuantity++;
    itemQtyElement.textContent = itemQuantity;
    updatePriceDetails();
}

// Decrease quantity
function decreaseQuantity() {
    if (itemQuantity > 1) {
        itemQuantity--;
        itemQtyElement.textContent = itemQuantity;
        updatePriceDetails();
    }
}
