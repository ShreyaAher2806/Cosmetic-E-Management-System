let currentIndex1 = 0;
let currentIndex2 = 0;

// Function to display the slide in the first slider
function showSlide(sliderId, index) {
  const slides = document.querySelectorAll(`#${sliderId} .slide`);
  const track = document.querySelector(`#${sliderId} .slide-track`);
  const sliderWidth = document.querySelector(`#${sliderId}`).clientWidth;
  
  // Ensure the index is within bounds
  if (index < 0) {
    index = slides.length - 1;
  } else if (index >= slides.length) {
    index = 0;
  }

  track.style.transform = `translateX(-${index * sliderWidth}px)`;

  // Update the current index
  if (sliderId === "slider1") {
    currentIndex1 = index;
  } else {
    currentIndex2 = index;
  }
}

// Next slide function for both sliders
function nextSlide(sliderNumber) {
  if (sliderNumber === 1) {
    currentIndex1 = (currentIndex1 + 1) % 6;
    showSlide("slider1", currentIndex1);
  } else {
    currentIndex2 = (currentIndex2 + 1) % 6;
    showSlide("slider2", currentIndex2);
  }
}

// Previous slide function for both sliders
function prevSlide(sliderNumber) {
  if (sliderNumber === 1) {
    currentIndex1 = (currentIndex1 - 1 + 6) % 6;
    showSlide("slider1", currentIndex1);
  } else {
    currentIndex2 = (currentIndex2 - 1 + 6) % 6;
    showSlide("slider2", currentIndex2);
  }
}

// Auto slide transition for both sliders
setInterval(() => {
  nextSlide(1); // Move the first slider every 5 seconds
}, 5000);

setInterval(() => {
  nextSlide(2); // Move the second slider every 5 seconds
}, 5000);

// Initialize both sliders
showSlide("slider1", currentIndex1);
showSlide("slider2", currentIndex2);

