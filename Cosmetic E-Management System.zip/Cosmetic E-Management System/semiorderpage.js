document.querySelector('.continue-button').addEventListener('click', () => {
    alert('Thank you for proceeding. No money will be deducted!');
});
