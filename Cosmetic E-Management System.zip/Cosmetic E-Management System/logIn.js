document.getElementById("register").addEventListener("submit", async (event) => {
    event.preventDefault();

    const user = {
        email: document.getElementById("username").value,
        password: document.getElementById("password").value,
    };

    const response = await fetch("http://localhost:8777/api/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
    });

    if (response.ok) {
        const message = await response.text();
        if (message === "Login successful!") {
            window.location.href = "Home.html";
        } else {
            alert("Invalid credentials!");
        }
    } else {
        alert("Error during login. Please try again.");
    }
});
