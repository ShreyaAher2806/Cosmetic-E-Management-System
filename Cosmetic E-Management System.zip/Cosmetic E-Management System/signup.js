// // Get the modal
// const modal = document.getElementById("popupModal");

// // Get the form
// const form = document.getElementById("signupForm");

// // Get the <span> element that closes the modal
// const closeButton = document.querySelector(".close-button");

// // When the user submits the form
// form.addEventListener("submit", function(event) {
//     event.preventDefault(); // Prevent actual form submission
//     // Here you can add form validation or send data to the server

//     // Show the modal
//     modal.style.display = "block";
// });

// // When the user clicks on <span> (x), close the modal
// closeButton.addEventListener("click", function() {
//     modal.style.display = "none";
// });

// // When the user clicks anywhere outside of the modal, close it
// window.addEventListener("click", function(event) {
//     if (event.target == modal) {
//         modal.style.display = "none";
//     }
// });
document.querySelector("form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const user = {
        name: document.getElementById("name").value,
        password: document.getElementById("password").value,
        email: document.getElementById("email").value,
        address: document.getElementById("address").value,
        contact: document.getElementById("contact").value,
    };

    const response = await fetch("http://localhost:8777/api/signup", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
    });

    if (response.ok) {
        const message = await response.text();
        alert(message); // "Signup successful!"
        document.getElementById("popupModal").style.display = "block";
    } else {
        alert("Signup failed. Please try again.");
    }
});
