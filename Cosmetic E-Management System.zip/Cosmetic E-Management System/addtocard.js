let cart = [];

// Toggle cart visibility
function toggleCart() {
    const cartElement = document.getElementById("cart");
    cartElement.style.display = cartElement.style.display === "none" ? "block" : "none";
}

// Add to Cart function
function addToCart(name, price) {
    const existingProduct = cart.find(item => item.name === name);
    if (existingProduct) {
        existingProduct.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }
    updateCart();
}

// Update Cart display
function updateCart() {
    const cartItemsContainer = document.getElementById("cart-items");
    const cartCount = document.getElementById("cart-count");
    const cartTotalElement = document.getElementById("cart-total");

    cartItemsContainer.innerHTML = ''; // Clear current cart display
    let totalItems = 0;
    let totalPrice = 0;

    cart.forEach((item, index) => {
        totalItems += item.quantity;
        totalPrice += item.price * item.quantity;

        const cartItem = document.createElement("div");
        cartItem.className = "cart-item";
        
        cartItem.innerHTML = `
            <span>${item.name} (x${item.quantity})</span>
            <span>₹${item.price * item.quantity}</span>
            <button onclick="removeFromCart(${index})">🗑️</button>
        `;
        
        cartItemsContainer.appendChild(cartItem);
    });

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = "<p>Your cart is empty.</p>";
    }

    cartTotalElement.innerHTML = `<p>Total: ₹${totalPrice}</p>`;
    cartCount.textContent = totalItems;
}

// Remove from Cart function
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}
